
  $(document).ready(function() {
    $('.chat-icon').click(function() {
      $('#chat-modal').modal('show');
    });
  });
